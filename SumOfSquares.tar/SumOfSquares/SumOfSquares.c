/*
##################################################################
#                                                                #
#   Created by : Nhat Nguyen                                     #
#   Email : nqnhat88@yahoo.com.vn                                #
#   This program calculates a sum of squares of some integers    #
#   excepting negatives.                                         #
#   Defaults: File input.txt at same source folder will be read  # 
#   and output the result to file output.txt.                    #
#                                                                #
##################################################################
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define TRUE 1
#define FALSE 0

struct nodestruct
{
  int value;
  struct nodestruct* next;
};
typedef struct nodestruct Node;

typedef struct
{
  Node* first;
} ArrayofNumber;

/* This funtion is to add one node at first position */
Node * Addfirst (ArrayofNumber * ar,int val)
{
  Node * TempNode = NULL;
  Node * Temp;
  TempNode = malloc (sizeof(Node));
  TempNode->value = val;
  TempNode->next = NULL;
  if(ar->first == NULL)
  {
    ar->first = TempNode;
  } 
  else
  {
    Temp = ar->first;
    ar->first= TempNode;
    TempNode->next = Temp;
  } 
  return ar->first;
}


int CalculationOfSum(ArrayofNumber * line)
{
  int TempSum=0;
  int Sum=0;
  int i=1;
  Node * pTraversal;
  pTraversal = line->first;
label0:
  if(pTraversal != NULL)
  {
    TempSum = pTraversal->value*i;
    i=10*i;
    Sum += TempSum;
    printf("\n Sum is %d", Sum);
    pTraversal = pTraversal->next;
    goto label0;
  }
  /* Square of Sum*/
  Sum = Sum * Sum;
  return Sum;
}

void FreeArrayOfNumber(ArrayofNumber * line)
{
  Node * pfree;
freelabel:
  pfree = line->first;
  if(pfree != NULL)
  {
    line->first = pfree->next;
    free(pfree); 
    goto freelabel;
  }
  return;
}

int getSumOfLine(FILE* file)
{
  bool NegativeFlag=FALSE;
  int sumOfEachLine=0;
  int getValue=0;
  ArrayofNumber* line=NULL;
  /* Initialise the data for number array */
  line = malloc (sizeof(ArrayofNumber));
  line->first = NULL;
label2:
  getValue = fgetc(file);
  printf("\nGet value %d", getValue - '0');
  if(getValue != 32 && getValue != 10)
  {
    if(getValue == 45) /* Detect negative number */
    {
      NegativeFlag = TRUE;
    }
    if(NegativeFlag == FALSE)
      line->first = Addfirst (line, getValue - '0');
    goto label2;
  }
  else
  {
    if(getValue == 32)
    {
      /* get sum when complete one number from file */
      if(NegativeFlag == FALSE)
      {
        sumOfEachLine += CalculationOfSum (line);
        printf("\nTime %d",line->first->value);
        FreeArrayOfNumber(line);
        line->first = NULL;
      }
       else
        /* Skip calculation if negative number is detected */
        NegativeFlag = FALSE;
      goto label2;
    }
    else
    {
      /* Final calculation at last number if number is integer*/
      if(line->first != NULL)
      {
        sumOfEachLine += CalculationOfSum (line);
        printf("\nTime %d",line->first->value);
        FreeArrayOfNumber(line);
        line->first = NULL;
      }
      free(line);
      return sumOfEachLine;
    }
  }
}

void SumOfSquares(FILE* file)
{
  FILE* w_file;
  char* filename="output.txt";
  char buf_len[50];
  int nOfTestcase;
  int amountOfNumber;
  int Results[100] = {[0 ... 99] = 0};
  int index1=0;
  w_file = fopen(filename,"w+");
  /* Parse the first line for the number of testcases*/
  nOfTestcase = fgetc(file);
  nOfTestcase = nOfTestcase - '0';
  fgetc(file);
  printf("%d",nOfTestcase);
label1:
  /* Parse all testcases and calculate sum */
  if(index1 < nOfTestcase)
  {
    /* Get the number of integers at each line */
    amountOfNumber = fgetc(file);
    fgetc(file); /* Move to new line */
    Results[index1]= getSumOfLine(file);
    printf("\nThe result of testcase %d is %d", index1, Results[index1]);
    sprintf(buf_len,"%d",Results[index1]);
    if(fputs((buf_len),w_file) == EOF)
    {
      perror("Error writing to target file");
      exit(0);
    }
    /* Adding new line to output file */
    if(index1 != (nOfTestcase - 1))
      fputc(10,w_file);
    index1++;
    goto label1;
  }
}
int main(int argc, char* argv[])
{
  char* filename = "input.txt";
  FILE* d_file;

  /* Open the file input.txt */
  d_file = fopen(filename, "r");
  if(!d_file)
  {
    perror("File does not exist");
    exit(0);
  }
  SumOfSquares(d_file);
  exit(0);
}
